<!-- navbar -->
      <!DOCTYPE html>
      <html>
      <head>
        <style type="text/css">
       .btn {
                  border: 1px solid black;
                  border-radius: 25px;
                  background-color: white;
                  color: black;
                  padding: 10px 28px;
                  font-size: 16px;
                  cursor: pointer;
                  margin: 5px;
                }

            .df:hover {
        color: white;
        font-size: 16px;
    background-color:black;
background-image:black;

}

        </style>
      </head>
      <body >

      <nav  class="navbar navbar-expand-md navbar-light bg-light" >
      <a class="navbar-brand" href="index.php"><h3> ModelBank </h3></a>

      <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="btn df" class="nav-link" href="index.php">Home</a>
              </li>

          </div>
       </nav>
     </body>
     </html>
